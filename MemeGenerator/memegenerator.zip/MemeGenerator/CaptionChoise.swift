//
//  CaptionChoise.swift
//  MemeGenerator
//
//  Created by Guilherme Wahlbrink on 2019-04-25.
//  Copyright © 2019 Guilherme Wahlbrink. All rights reserved.
//

import Foundation


struct CaptionOption {
    let emoji: String
    let caption: String
}
